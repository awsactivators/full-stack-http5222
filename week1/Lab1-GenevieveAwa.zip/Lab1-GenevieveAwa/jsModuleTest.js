// Import the modules from the jsModuleCode.js to be used
import { addnewString, returnNumberItem } from "./jsModuleCode.js";

// Executing the add a new string function
addnewString();

// Executing the return the number of items in the array
returnNumberItem();